@extends('layouts.nav')

@section('content')
<center>
    <br>
    <strong><font size="6"><p>você é um administrador!</p></font></strong>
    <br><br><br>
    
    <font size="7">
<ul>
    <p><a href="/inserir/comercio">Inserir um novo comercio</a>
    <p><a href="/lista/comercios">Lista de Comercios</a>
</ul>
</font>
</center>
</div>
<br>
@stop