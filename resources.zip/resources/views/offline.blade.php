@extends('nav.app')

@section('content')

    <h1>Você está offline</h1>

@endsection